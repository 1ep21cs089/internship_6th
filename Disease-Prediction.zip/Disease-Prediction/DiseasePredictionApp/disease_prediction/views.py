from django.shortcuts import render
from .forms import SymptomInputForm
import joblib
import os

# Load the model (assumes your model is saved as a joblib file in the "saved_model" folder)
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'saved_model', 'decision_tree.joblib')
model = joblib.load(MODEL_PATH)

def home(request):
    return render(request, 'disease_prediction/home.html')

def predict_disease(request):
    if request.method == 'POST':
        form = SymptomInputForm(request.POST)
        if form.is_valid():
            symptoms = {
                'itching': form.cleaned_data.get('itching', False),
                'skin_rash': form.cleaned_data.get('skin_rash', False),
                'nodal_skin_eruptions': form.cleaned_data.get('nodal_skin_eruptions', False),
                'continuous_sneezing': form.cleaned_data.get('continuous_sneezing', False),
                'shivering': form.cleaned_data.get('shivering', False),
                'chills': form.cleaned_data.get('chills', False),
                'joint_pain': form.cleaned_data.get('joint_pain', False),
                'stomach_pain': form.cleaned_data.get('stomach_pain', False),
                'acidity': form.cleaned_data.get('acidity', False),
                'ulcers_on_tongue': form.cleaned_data.get('ulcers_on_tongue', False),
                'muscle_wasting': form.cleaned_data.get('muscle_wasting', False),
                'vomiting': form.cleaned_data.get('vomiting', False),
                'burning_micturition': form.cleaned_data.get('burning_micturition', False),
                'spotting_urination': form.cleaned_data.get('spotting_urination', False),
                'fatigue': form.cleaned_data.get('fatigue', False),
                'weight_gain': form.cleaned_data.get('weight_gain', False),
                'anxiety': form.cleaned_data.get('anxiety', False),
                'cold_hands_and_feets': form.cleaned_data.get('cold_hands_and_feets', False),
                'mood_swings': form.cleaned_data.get('mood_swings', False),
                'weight_loss': form.cleaned_data.get('weight_loss', False),
                'restlessness': form.cleaned_data.get('restlessness', False),
                'lethargy': form.cleaned_data.get('lethargy', False),
                'patches_in_throat': form.cleaned_data.get('patches_in_throat', False),
                'irregular_sugar_level': form.cleaned_data.get('irregular_sugar_level', False),
                'cough': form.cleaned_data.get('cough', False),
                'high_fever': form.cleaned_data.get('high_fever', False),
                'sunken_eyes': form.cleaned_data.get('sunken_eyes', False),
                'breathlessness': form.cleaned_data.get('breathlessness', False),
                'sweating': form.cleaned_data.get('sweating', False),
                'dehydration': form.cleaned_data.get('dehydration', False),
                'indigestion': form.cleaned_data.get('indigestion', False),
                'headache': form.cleaned_data.get('headache', False),
                'yellowish_skin': form.cleaned_data.get('yellowish_skin', False),
                'dark_urine': form.cleaned_data.get('dark_urine', False),
                'nausea': form.cleaned_data.get('nausea', False),
                'loss_of_appetite': form.cleaned_data.get('loss_of_appetite', False),
                'pain_behind_the_eyes': form.cleaned_data.get('pain_behind_the_eyes', False),
                'back_pain': form.cleaned_data.get('back_pain', False),
                'constipation': form.cleaned_data.get('constipation', False),
                'abdominal_pain': form.cleaned_data.get('abdominal_pain', False),
                'diarrhoea': form.cleaned_data.get('diarrhoea', False),
                'mild_fever': form.cleaned_data.get('mild_fever', False),
                'yellow_urine': form.cleaned_data.get('yellow_urine', False),
                'yellowing_of_eyes': form.cleaned_data.get('yellowing_of_eyes', False),
                'acute_liver_failure': form.cleaned_data.get('acute_liver_failure', False),
                'fluid_overload': form.cleaned_data.get('fluid_overload', False),
                'swelling_of_stomach': form.cleaned_data.get('swelling_of_stomach', False),
                'swelled_lymph_nodes': form.cleaned_data.get('swelled_lymph_nodes', False),
                'malaise': form.cleaned_data.get('malaise', False),
                'blurred_and_distorted_vision': form.cleaned_data.get('blurred_and_distorted_vision', False),
                'phlegm': form.cleaned_data.get('phlegm', False),
                'throat_irritation': form.cleaned_data.get('throat_irritation', False),
                'redness_of_eyes': form.cleaned_data.get('redness_of_eyes', False),
                'sinus_pressure': form.cleaned_data.get('sinus_pressure', False),
                'runny_nose': form.cleaned_data.get('runny_nose', False),
                'congestion': form.cleaned_data.get('congestion', False),
                'chest_pain': form.cleaned_data.get('chest_pain', False),
                'weakness_in_limbs': form.cleaned_data.get('weakness_in_limbs', False),
                'fast_heart_rate': form.cleaned_data.get('fast_heart_rate', False),
                'pain_during_bowel_movements': form.cleaned_data.get('pain_during_bowel_movements', False),
                'pain_in_anal_region': form.cleaned_data.get('pain_in_anal_region', False),
                'bloody_stool': form.cleaned_data.get('bloody_stool', False),
                'irritation_in_anus': form.cleaned_data.get('irritation_in_anus', False),
                'neck_pain': form.cleaned_data.get('neck_pain', False),
                'dizziness': form.cleaned_data.get('dizziness', False),
                'cramps': form.cleaned_data.get('cramps', False),
                'bruising': form.cleaned_data.get('bruising', False),
                'obesity': form.cleaned_data.get('obesity', False),
                'swollen_legs': form.cleaned_data.get('swollen_legs', False),
                'swollen_blood_vessels': form.cleaned_data.get('swollen_blood_vessels', False),
                'puffy_face_and_eyes': form.cleaned_data.get('puffy_face_and_eyes', False),
                'enlarged_thyroid': form.cleaned_data.get('enlarged_thyroid', False),
                'brittle_nails': form.cleaned_data.get('brittle_nails', False),
                'swollen_extremeties': form.cleaned_data.get('swollen_extremeties', False),
                'excessive_hunger': form.cleaned_data.get('excessive_hunger', False),
                'extra_marital_contacts': form.cleaned_data.get('extra_marital_contacts', False),
                'drying_and_tingling_lips': form.cleaned_data.get('drying_and_tingling_lips', False),
                'slurred_speech': form.cleaned_data.get('slurred_speech', False),
                'knee_pain': form.cleaned_data.get('knee_pain', False),
                'hip_joint_pain': form.cleaned_data.get('hip_joint_pain', False),
                'muscle_weakness': form.cleaned_data.get('muscle_weakness', False),
                'stiff_neck': form.cleaned_data.get('stiff_neck', False),
                'swelling_joints': form.cleaned_data.get('swelling_joints', False),
                'movement_stiffness': form.cleaned_data.get('movement_stiffness', False),
                'spinning_movements': form.cleaned_data.get('spinning_movements', False),
                'loss_of_balance': form.cleaned_data.get('loss_of_balance', False),
                'unsteadiness': form.cleaned_data.get('unsteadiness', False),
                'weakness_of_one_body_side': form.cleaned_data.get('weakness_of_one_body_side', False),
                'loss_of_smell': form.cleaned_data.get('loss_of_smell', False),
                'bladder_discomfort': form.cleaned_data.get('bladder_discomfort', False),
                'foul_smell_of_urine': form.cleaned_data.get('foul_smell_of_urine', False),
                'continuous_feel_of_urine': form.cleaned_data.get('continuous_feel_of_urine', False),
                'passage_of_gases': form.cleaned_data.get('passage_of_gases', False),
                'internal_itching': form.cleaned_data.get('internal_itching', False),
                'toxic_look_typhos': form.cleaned_data.get('toxic_look_typhos', False),
                'depression': form.cleaned_data.get('depression', False),
                'irritability': form.cleaned_data.get('irritability', False),
                'muscle_pain': form.cleaned_data.get('muscle_pain', False),
                'altered_sensorium': form.cleaned_data.get('altered_sensorium', False),
                'red_spots_over_body': form.cleaned_data.get('red_spots_over_body', False),
                'belly_pain': form.cleaned_data.get('belly_pain', False),
                'abnormal_menstruation': form.cleaned_data.get('abnormal_menstruation', False),
                'dischromic_patches': form.cleaned_data.get('dischromic_patches', False),
                'watering_from_eyes': form.cleaned_data.get('watering_from_eyes', False),
                'increased_appetite': form.cleaned_data.get('increased_appetite', False),
                'polyuria': form.cleaned_data.get('polyuria', False),
                'family_history': form.cleaned_data.get('family_history', False),
                'mucoid_sputum': form.cleaned_data.get('mucoid_sputum', False),
                'rusty_sputum': form.cleaned_data.get('rusty_sputum', False),
                'lack_of_concentration': form.cleaned_data.get('lack_of_concentration', False),
                'visual_disturbances': form.cleaned_data.get('visual_disturbances', False),
                'receiving_blood_transfusion': form.cleaned_data.get('receiving_blood_transfusion', False),
                'receiving_unsterile_injections': form.cleaned_data.get('receiving_unsterile_injections', False),
                'coma': form.cleaned_data.get('coma', False),
                'stomach_bleeding': form.cleaned_data.get('stomach_bleeding', False),
                'distention_of_abdomen': form.cleaned_data.get('distention_of_abdomen', False),
                'history_of_alcohol_consumption': form.cleaned_data.get('history_of_alcohol_consumption', False),
                'fluid_overload': form.cleaned_data.get('fluid_overload', False),
                'blood_in_sputum': form.cleaned_data.get('blood_in_sputum', False),
                'prominent_veins_on_calf': form.cleaned_data.get('prominent_veins_on_calf', False),
                'palpitations': form.cleaned_data.get('palpitations', False),
                'painful_walking': form.cleaned_data.get('painful_walking', False),
                'pus_filled_pimples': form.cleaned_data.get('pus_filled_pimples', False),
                'blackheads': form.cleaned_data.get('blackheads', False),
                'scurring': form.cleaned_data.get('scurring', False),
                'skin_peeling': form.cleaned_data.get('skin_peeling', False),
                'silver_like_dusting': form.cleaned_data.get('silver_like_dusting', False),
                'small_dents_in_nails': form.cleaned_data.get('small_dents_in_nails', False),
                'inflammatory_nails': form.cleaned_data.get('inflammatory_nails', False),
                'blister': form.cleaned_data.get('blister', False),
                'red_sore_around_nose': form.cleaned_data.get('red_sore_around_nose', False),
                'yellow_crust_ooze': form.cleaned_data.get('yellow_crust_ooze', False),
            }
            print("Form is valid. Symptoms:", symptoms)  # Debug statement
            
            # Convert the symptoms dictionary to a format suitable for the model
            symptoms_list = [int(value) for value in symptoms.values()]
            
            # Make prediction
            prediction = model.predict([symptoms_list])
            
            # Map prediction to disease name if needed
            # This assumes the model outputs an integer representing the disease class
            disease_mapping = {0: 'Disease A', 1: 'Disease B', 2: 'Disease C'}
            predicted_disease = disease_mapping.get(prediction[0], 'Unknown Disease')
            
            print("Predicted Disease:", predicted_disease)  # Debug statement
            
            return render(request, 'disease_prediction/result.html', {'symptoms': symptoms, 'predicted_disease': predicted_disease})
        else:
            print("Form is not valid.")  # Debug statement
    else:
        form = SymptomInputForm()
    
    return render(request, 'disease_prediction/predict_disease.html', {'form': form})
